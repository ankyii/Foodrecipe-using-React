import './App.css';
import Navbar from './Component/Pages/Navbar';
import Search from './Component/Pages/Search';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import Home1 from './Component/Pages/Home1';
import Vegans from './Component/Pages/Vegans';
import { useState } from 'react';
import SearchResult from './Component/Pages/SearchResult';
import Bb from "./Component/Pages/Bb";
import Sabji from "./Component/Pages/Sabji";
import Breakfast from "./Component/Pages/Breakfast";
import NotFound from './Component/Pages/NotFound';

function App() {
  return (
    <Router>
    <div>
    <Navbar/>
      <Switch>
      <Route path="/Home1">
        <Home1/>
      </Route>
      <Route path="/Search">
        <Search/>
      </Route>
      <Route exact path="/">
        <Home1/>
      </Route>
      <Route path="/Vegans">
        <Vegans/>
      </Route>
      <Route path="/Sabji">
        <Sabji/>
      </Route>
      <Route path="/Breakfast">
        <Breakfast/>
      </Route>
      <Route exact path="/Bb/:Id" component={Bb} />
      <Route path="/SearchResult/:R_Name" component={SearchResult}/>
      </Switch>
      <Route component={NotFound} />
      </div>
      </Router>
  );
}

export default App;
