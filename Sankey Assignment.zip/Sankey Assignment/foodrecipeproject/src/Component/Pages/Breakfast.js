import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Navbar from "./Navbar";


function Breakfast() {
  const [Recipe,SetRecipe] =useState([]);
    useEffect(()=>{
      axios.get('http://localhost:3001/Search3').then((response)=>{
        console.log(response.data.users);
        SetRecipe(response.data);
      })
    },[]);
  

  return (<div>
      
    {Recipe.map((val) => {
                return <>
                 <div class="container">
     <div class="row align-items-center vh-100">
         <div class="col-6 mx-auto">
             <div class="card shadow border">
             <img src={val.R_Image} class="card-img-top" alt="..." />
                 <div class="card-body d-flex flex-column align-items-center">
                 <h5 class="card-title text-uppercase fw-bolder">{val.R_Name}</h5>
                     <p class="card-text text-center">{val.R_Description}</p>
                     <Link class="btn btn-primary mr-2" to={`/Bb/${val.Id}`}>
            View
      </Link>
                 </div>
             </div>
         </div>
     </div>
 </div>
 </>
            })}
            
  
    </div>
  );
}

export default Breakfast;