import axios from "axios";
import React, { useEffect, useState } from "react";
import SearchResult from "./SearchResult";
import { Link } from "react-router-dom";

function Search() {
  const [R_Name, Setname] = useState("");
  const onInputChange = (e) => {
    Setname(e.target.value);
  };
  
  return (<>
<div class="d-flex" action="Post">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Your Name"
              name="R_Name"
              value={R_Name}
              onChange={e => onInputChange(e)}
            />
            <Link class="btn btn-primary mr-2" to={`/SearchResult/${R_Name}`}>
           View
     </Link>
            
        </div>
        
    </>
  );
}

export default Search;