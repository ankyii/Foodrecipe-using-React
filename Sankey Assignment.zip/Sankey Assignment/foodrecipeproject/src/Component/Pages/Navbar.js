import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Search from "./Search";


function Navbar() {
  return (<>
      <div class="container-fluid d-flex justify-content-center text-warning bg-dark">
        <Link to="/" class="navbar-brand text-warning">Food Recipe</Link>
      </div>
    
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <Link to="/" class="nav-link active" >Home</Link>
            </li>
            <li class="nav-item">
              <Link to="/Vegans" class="nav-link active" >Dal</Link>
            </li>
            <li class="nav-item">
              <Link to="/Sabji" class="nav-link active" >Sabji</Link>
            </li>
            <li class="nav-item">
              <Link to="/Breakfast" class="nav-link active" >Breakfast</Link>
            </li>
          </ul><Search/>
        </div>
    </nav>
  
    </>
  );
}
export default Navbar;