import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import Navbar from "./Navbar";




function Bb() {

    const [Recipe, SetRecipe] = useState([]);
    const { Id } = useParams();
    useEffect(() => {
        axios.get(`http://localhost:3001/Set/${Id}`).then((response) => {
            console.log(response);
            SetRecipe(response.data);
        });
    }, []);


    return (<>
        {Recipe.map((val) => {
            const { Id, R_Name, R_Ingrediants,R_Description, R_Procedure, R_Image, R_Video, Type } = val;
            return <>
            <br></br>
                <section className="section">
                    <div>
                        <section className="section">
                            <div className="container">
                                <div className="card shadow">
                                    <div className="card-body">
                                        <div className="row">
                                            <div className="col-md-6">
                                                <div className="Card shadow">
                                                    <img src={val.R_Image} className="w-100 border-bottom" />
                                                </div>
                                            </div>
                                            <div className="col-md-6 border-start">
                                                <div className="card-body">
                                                    <h1 className="main-heading">{val.R_Name}</h1>
                                                    <br />
                                                    <br />
                                                    <h2 className="text-warning ">{val.R_Description}</h2>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                    </div>

                </section>
                <div>
                    <section className="p-3 mb-2 bg-warning text-dark">
                        <div className="container ">
                            <div className="row">
                                <div className="col-md-4 my-auto">
                                </div>
                            </div>
                        </div>
                    </section>
                    <hr />
                    <section className="section bg-light border-bottom">
                        <div className="container">
                            <h5 className="main-heading text-center text-warning">Ingridiants</h5>
                            <div className="underline"></div>
                            <p>
                                <div className="underline">
                                    <p class="text-success text-center">
                                        {val.R_Ingrediants}
                                    </p>
                                </div>
                            </p>
                        </div>
                        <div className="container py-4">
                            <h5 className="main-heading text-center text-warning">Procedure</h5>
                            <div className="underline text-center">
                            <p>
                                {val.R_Procedure}
                            </p>
                            </div>
                        </div>
                    </section>
                    <hr></hr>
                    <div className="text-center ">
                    <a href={val.R_Video} >
                        <button type="button" class="btn btn-warning">Click to get video</button>
                    </a>
                    </div>
                    <br />
                    <br />
                </div>
            </>
        })}
    </>
    );
}

export default Bb;