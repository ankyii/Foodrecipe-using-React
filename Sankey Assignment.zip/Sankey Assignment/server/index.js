const express =require('express')
const bodyParser = require('body-parser');
const cors= require('cors');
const app=express()
const mysql= require('mysql');

const db= mysql.createPool({
    host: "localhost",
    user: "root",
    password: "",
    database: "food",
});

app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({extended:true}))

app.get("/Search",(req, res) => {
    const sqlSelect="select * from foodrecipe";
    db.query(sqlSelect, (err, result) => {
        res.send(result);
        console.log(result);
    })
});
app.get('/set/:Id', (req,res)=>{
    const Id  = req.params.Id;
    console.log('Request Id:', req.params.Id);
    const sqlSelect="select * from foodrecipe where Id= ?";
    db.query(sqlSelect, [Id], (err,result)=>{
        res.send(result);
    })   
});

app.get('/set2/:R_Name', (req,res)=>{
    const R_Name  = req.params.R_Name;
    console.log('Request Id:', req.params.R_Name);
    const sqlSelect="select * from foodrecipe where R_Name= ?";
    db.query(sqlSelect, [R_Name], (err,result)=>{
        res.send(result);
        console.log(result);
    })   
});

app.post("/set", (req,res)=>{
    const Search=req.body.Search;
    const sqlInsert="select * from foodrecipe where R_Name=?";
    db.query(sqlInsert,[Search], (err,result)=>{
        console.log(result);
        res.send(result);
    })   
});

app.post("/set1", (req,res)=>{
    const user=req.body.user;
    const sqlInsert="select * from foodrecipe where Id=?";
    db.query(sqlInsert,[user], (err,result)=>{
        console.log(result);
        res.send(result);
    })   
});

app.get("/Search1", (req,res)=>{
    const sqlSelect="select * from foodrecipe where Type='Dal'";
    db.query(sqlSelect, (err,result)=>{
        console.log(result);
       res.send(result);
    })   
});

app.get("/Search2", (req,res)=>{
    const sqlSelect="select * from foodrecipe where Type='Sabji'";
    db.query(sqlSelect, (err,result)=>{
        console.log(result);
       res.send(result);
    })   
});

app.get("/Search3", (req,res)=>{
    const sqlSelect="select * from foodrecipe where Type='Breakfast'";
    db.query(sqlSelect, (err,result)=>{
        console.log(result);
       res.send(result);
    })   
});

app.put('/set/:Id', function (req, res, next) {
    console.log('Request Id:', req.params.Id);
    next();
  });

app.listen(3001, ()=>{
    console.log("running on port 3001");
});